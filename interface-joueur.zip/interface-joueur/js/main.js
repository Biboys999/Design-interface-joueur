window.onload = function () {
    let acceuil = document.querySelector("#ac")
    let résseyer = document.querySelector("#re")
    let gagner = document.querySelector("#win")
    let perdu = document.querySelector("#loose")
    let button = document.getElementsByClassName('.button')


    résseyer.style.display = "none";
    gagner.style.display = "none";
    perdu.style.display = "none";

    const aléatoire = Math.floor((Math.random() * 10) + 1)

    function ras(){
        var num1 = document.querySelector('#utilisateur1').value
        let counter = 0
        while (counter < 3) {
            if (num1 === aléatoire) {
                acceuil.style.display = "none";
                gagner.style.display = "inline";
                break
            }
            else {
                counter++
                if (num2 !== aléatoire) {
                    acceuil.style.display = "none";
                    résseyer.style.display = "inline";
                }
            }
            if (counter == 3) {
                résseyer.style.display = "none";
                perdu.style.display = "inline";
            }
        }
    }
}
/*
window.onload = function(){
    let lightOff = document.querySelector("#loff")
    let lightOn = document.querySelector("#lon")
    let swtOff = document.querySelector("#boff")
    let swtOn = document.querySelector("#bon")
    lightOff.style.display = "none";
    swtOn.style.display = "none";

    swtOn.onclick = function(){
        lightOff.style.display = "none";
        swtOn.style.display = "none";
        lightOn.style.display = "inline";
        swtOff.style.display = "inline";

        }

    swtOff.onclick = function(){
        lightOn.style.display = "none";
        swtOff.style.display = "none";
        lightOff.style.display = "inline";
        swtOn.style.display = "inline";
    }

}
    function function1() {
        var num1 = parseInt(document.getElementById('utilisateur1').value)
        document.getElementById('ac').innerHTML = num1;
    }
    function function2() {
        var num2 = parseInt(document.getElementById('utilisateur2').value)
        document.getElementById('re').innerHTML = num2;
    }

function function1() {
        var num1 = parseInt(document.getElementById('utilisateur1').value)
        document.getElementById('ac').innerHTML = num1;
        if (num1 === aléatoire) {
            button.onclick = function () {
                acceuil.style.display = "none";
                gagner.style.display = "inline";
            }
        if (num1 !== aléatoire) {
            button.onclick = function () {
                acceuil.style.display = "none";
                résseyer.style.display = "inline";
            }
        }
        } else {

        }
    }


<article>
    <img id="lon" class="lp img1" src="img/solei.jpg" alt="">
    <img id="loff" class="lp img1" src="img/nuit.jpeg" alt="">
    <img id="bon" class="bt img2" src="img/solei2.0.png" alt="">
    <img id="boff" onclick="play()" class="bt img2" src="img/nuit2.0.png" alt="">
</article>
*/
