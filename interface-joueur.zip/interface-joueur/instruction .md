\1. Le systeme genere un nombre aléatoire compris entre 1 et 10



\2. Le joueur a droit à 3 tentatives pour deviner ce nombre



\3. S'il trouve le nombre avant les 3 tentatives, il est déclaré gagnant



\4. Sinon il est déclaré perdant



\5. Il a la possibilité de toujours refaire une nouvelle partie